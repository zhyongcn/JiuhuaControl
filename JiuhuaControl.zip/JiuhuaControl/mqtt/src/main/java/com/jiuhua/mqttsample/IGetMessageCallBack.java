package com.jiuhua.mqttsample;

public interface IGetMessageCallBack {
    void setMessage(String message);
}
