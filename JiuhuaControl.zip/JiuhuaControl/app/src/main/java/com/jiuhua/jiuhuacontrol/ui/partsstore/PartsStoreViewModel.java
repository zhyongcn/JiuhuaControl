package com.jiuhua.jiuhuacontrol.ui.partsstore;

import androidx.lifecycle.ViewModel;

public class PartsStoreViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
